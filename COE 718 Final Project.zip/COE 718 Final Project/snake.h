#ifndef __snake_h
#define __snake_h

extern int snakegame();
extern void delay();
extern int snakegame(void);


#endif