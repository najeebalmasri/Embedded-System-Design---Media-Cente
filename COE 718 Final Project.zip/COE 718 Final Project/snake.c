#include "stdio.h"
#include "stdlib.h"
#include "LPC17xx.h"
#include "KBD.h"
#include "GLCD.h"
#include "LED.h"

#define DELAY_2N 20
#define GRID_WIDTH 20
#define GRID_HEIGHT 10
#define MAX_SNAKE_SIZE 100

// Variables
int xpos, ypos, size, direction, prev_direction, score, speed, collision;
int snake[MAX_SNAKE_SIZE][2];
int food_x, food_y;
int border_enabled = 1;

// Function Prototypes
void delay(int count);
void initialize_game(void);
void generate_food(void);
void draw_snake(void);
void clear_snake(void);
void update_snake_position(void);
void check_collision(void);
void render_grid(void);
void game_over_screen(void);
void update_score(void);

// Delay Function
void delay(int count) 
{
    count <<= DELAY_2N;
    while (count--);
}

// Initialize Game
void initialize_game(void)
{
    GLCD_Clear(Black);
    xpos = GRID_HEIGHT / 2;
    ypos = GRID_WIDTH / 2;
    size = 3;
    direction = 0; // Right
    prev_direction = -1;
    score = 0;
    speed = 15;
    collision = 0;
    generate_food();
    render_grid();
    draw_snake();
    update_score();
}

// Generate Food at Random Position
void generate_food(void) 
{
    int valid = 0, i;
    while (!valid) 
		{
        food_x = rand() % GRID_HEIGHT;
        food_y = rand() % GRID_WIDTH;
        valid = 1;
        for (i = 0; i < size; i++) {
            if (snake[i][0] == food_x && snake[i][1] == food_y) 
						{
                valid = 0; 
                break;
            }
        }
    }
    GLCD_SetTextColor(Red);
    GLCD_DisplayChar(food_x, food_y, 1, 0x94);
}

// Render Grid Borders
void render_grid(void)
{
    int x, y;
    if (border_enabled)
			{
        GLCD_SetTextColor(White);
        for (x = 0; x < GRID_HEIGHT; x++)
				{
            GLCD_DisplayChar(x, 0, 1, '|');
            GLCD_DisplayChar(x, GRID_WIDTH - 1, 1, '|');
        }
        for (y = 0; y < GRID_WIDTH; y++) 
				{
            GLCD_DisplayChar(0, y, 1, '-');
            GLCD_DisplayChar(GRID_HEIGHT - 1, y, 1, '-');
        }
    }
}

// Draw Snake
void draw_snake(void)
	{
    int i;
    for (i = 0; i < size; i++) 
		{
        if (i == 0) 
				{
            GLCD_SetTextColor(Green);
            GLCD_DisplayChar(snake[i][0], snake[i][1], 1, 0x88); 
        } else 
				{
            GLCD_SetTextColor(Blue);
            GLCD_DisplayChar(snake[i][0], snake[i][1], 1, 0x87); 
        }
    }
}

// Clear Snake
void clear_snake(void) 
	{
    int i;
    for (i = 0; i < size; i++) 
		{
        GLCD_SetTextColor(Black);
        GLCD_DisplayChar(snake[i][0], snake[i][1], 1, ' ');
    }
}

// Update Snake Position
void update_snake_position(void) 
	{
    int i;
    clear_snake();
    for (i = size - 1; i > 0; i--) 
		{
        snake[i][0] = snake[i - 1][0];
        snake[i][1] = snake[i - 1][1];
    }
    if (direction == 0) ypos++;
    else if (direction == 1) ypos--;
    else if (direction == 2) xpos++;
    else if (direction == 3) xpos--;

    snake[0][0] = xpos;
    snake[0][1] = ypos;
    draw_snake();
}

// Check for Collisions
void check_collision(void) 
	{
    int i;
    // Collision with borders
    if (border_enabled) {
        if (xpos < 1 || xpos >= GRID_HEIGHT - 1 || ypos < 1 || ypos >= GRID_WIDTH - 1) 
				{
            collision = 1;
        }
    }

    // Collision with self
    for (i = 1; i < size; i++) 
		{
        if (snake[0][0] == snake[i][0] && snake[0][1] == snake[i][1]) 
				{
            collision = 1;
        }
    }

    // Eating food
    if (snake[0][0] == food_x && snake[0][1] == food_y) 
		{
        size++;
        score += 10;
        if (speed > 5) speed--;
        generate_food();
        update_score();
    }
}

// Update Score Display
void update_score(void) 
{
    char str[20];
    GLCD_SetTextColor(Yellow);
    GLCD_DisplayString(0, 0, 1, "Score: ");
    sprintf(str, "%d", score);
    GLCD_DisplayString(0, 7, 1, (unsigned char *)str);
}

// Display Game Over Screen
void game_over_screen(void) 
{
    char str[20];
    GLCD_Clear(Red);
    GLCD_SetTextColor(White);
    GLCD_DisplayString(5, 5, 1, "GAME OVER");
    sprintf(str, "Score: %d", score);
    GLCD_DisplayString(6, 5, 1, (unsigned char *)str);
}

// Main Snake Game Function
int snakegame(void) {
    initialize_game();

    while (!collision) 
		{
        int joystick_val = get_button();
        if (joystick_val != prev_direction) 
				{
            if (joystick_val == KBD_UP && direction != 2) direction = 3;
            else if (joystick_val == KBD_DOWN && direction != 3) direction = 2;
            else if (joystick_val == KBD_LEFT && direction != 0) direction = 1;
            else if (joystick_val == KBD_RIGHT && direction != 1) direction = 0;
            prev_direction = joystick_val;
        }

        update_snake_position();
        check_collision();
        delay(speed);
    }

    game_over_screen();
    return 0;
}
