#include <LPC17xx.H>                    /* NXP LPC17xx definitions            */
#include "string.h"
#include "GLCD.h"
#include "LED.h"
#include "KBD.h"
#include "PHOTO_VIEWER.h"
#include "usbdmain.h"
#include "game_on.h"
#include "snake.h"

// Define menu indices for readability
#define PHOTO_VIEWER 1
#define AUDIO_PLAYER 2
#define GAME_CENTRE 3

// Define sub-menu indices for Game Centre
#define MEMORY_GAME 1
#define SNAKE_GAME 2

// Declaration of audio main function
extern int audio_main(void); 

// Function Prototypes
void resetMainMenu(void);
void executeTask(int selector);
void displayGameCentreMenu(int selector);
void executeGameCentreTask(int selector);

// Main Function
int main(void) 
{
    int selector = 0; // Current menu item
    int joystick_val = 0;
    int joystick_prev = 0;

    // Initialize peripherals
    KBD_Init();
    LED_Init();
    GLCD_Init();
    GLCD_Clear(Black);
    SysTick_Config(SystemCoreClock / 100);

    // Display initial menu
    resetMainMenu();

    // Infinite loop for menu navigation
    for (;;) {
        joystick_val = get_button(); // Read joystick input

        // Handle joystick input only when it changes
        if (joystick_val != joystick_prev) 
					{
            if (joystick_val == KBD_DOWN) 
							{
                selector = (selector % GAME_CENTRE) + 1; // Increment selector
            } else if (joystick_val == KBD_UP) 
							{
                selector = (selector == 1) ? GAME_CENTRE : selector - 1; // Decrement selector
            } else if (joystick_val == KBD_RIGHT) 
							{
                if (selector == GAME_CENTRE) 
									{
                    int game_selector = 1; // Default to the first game in Game Centre
                    displayGameCentreMenu(game_selector);
                    for (;;)
										{
                        joystick_val = get_button(); // Handle Game Centre navigation
                        if (joystick_val != joystick_prev)
													{
                            if (joystick_val == KBD_DOWN) 
															{
                                game_selector = (game_selector % SNAKE_GAME) + 1; // Increment selector
                            } else if (joystick_val == KBD_UP)
															{
                                game_selector = (game_selector == 1) ? SNAKE_GAME : game_selector - 1; // Decrement selector
                            } else if (joystick_val == KBD_RIGHT)
															{
                                executeGameCentreTask(game_selector); // Execute selected game
                                break; // Return to main menu
                            } else if (joystick_val == KBD_LEFT)
															{
                                resetMainMenu(); // Return to main menu
                                break;
                            }
                            displayGameCentreMenu(game_selector); // Update Game Centre menu
                            joystick_prev = joystick_val;
                        }
                    }
                } else {
                    executeTask(selector); // Execute selected task
                }
            }
            joystick_prev = joystick_val;
        }

        // Update menu display based on selector
        switch (selector) {
            case PHOTO_VIEWER:
						{
                GLCD_SetBackColor(Black);
                GLCD_SetTextColor(Red);  // Highlighted color
                GLCD_DisplayString(4, 2, 1, ">> Photo Viewer");
                GLCD_SetTextColor(Blue);
                GLCD_DisplayString(5, 2, 1, "[*] Audio Player");
                GLCD_DisplayString(6, 2, 1, "[*] Game Centre");
                break;
            }
            case AUDIO_PLAYER:
						{
                GLCD_SetBackColor(Black);
                GLCD_SetTextColor(Blue);
                GLCD_DisplayString(4, 2, 1, "[*] Photo Viewer");
                GLCD_SetTextColor(Red);  // Highlighted color
                GLCD_DisplayString(5, 2, 1, ">> Audio Player");
                GLCD_SetTextColor(Blue);
                GLCD_DisplayString(6, 2, 1, "[*] Game Centre");
                break;
            }
            case GAME_CENTRE: 
						{
                GLCD_SetBackColor(Black);
                GLCD_SetTextColor(Blue);
                GLCD_DisplayString(4, 2, 1, "[*] Photo Viewer");
                GLCD_DisplayString(5, 2, 1, "[*] Audio Player");
                GLCD_SetTextColor(Red);  // Highlighted color
                GLCD_DisplayString(6, 2, 1, ">> Game Centre");
                break;
            }
            default:
                resetMainMenu();
                break;
        }
    }
}

// Reset menu to initial state
void resetMainMenu(void) 
{
    int i; // Declare loop variable outside the loop

    // Clear screen
    GLCD_Clear(Black);

    // Draw borders
    GLCD_SetTextColor(White);
    for (i = 0; i < 320; i++) 
	{
        GLCD_PutPixel(i, 0);    // Top border
        GLCD_PutPixel(i, 239);  // Bottom border
    }
    for (i = 0; i < 240; i++) 
		{
        GLCD_PutPixel(0, i);    // Left border
        GLCD_PutPixel(319, i);  // Right border
    }

    // Display header
    GLCD_SetBackColor(Black);
    GLCD_SetTextColor(Yellow);
    GLCD_DisplayString(0, 5, 1, "Final Project");
    GLCD_SetTextColor(Green);
    GLCD_DisplayString(1, 5, 1, "Media Center");

    // Display menu items
    GLCD_SetTextColor(Blue);
    GLCD_DisplayString(4, 2, 1, "[*] Photo Viewer");
    GLCD_DisplayString(5, 2, 1, "[*] Audio Player");
    GLCD_DisplayString(6, 2, 1, "[*] Game Centre");
}

// Execute the selected task
void executeTask(int selector) 
{
    GLCD_Clear(White); // Clear screen for task execution
    switch (selector) {
        case PHOTO_VIEWER:
            photo_viewer(1); // Start photo viewer
            break;
        case AUDIO_PLAYER:
            audio_main(); // Start audio player
            break;
        default:
            break;
    }
    resetMainMenu(); // Return to menu after task
}

// Display the Game Centre menu
void displayGameCentreMenu(int selector) 
{
    GLCD_Clear(Black);
    GLCD_SetBackColor(Black);
    GLCD_SetTextColor(Blue);
    GLCD_DisplayString(0, 4, 1, "Game Centre");
    GLCD_DisplayString(4, 2, 1, "Memory Game");
    GLCD_DisplayString(5, 2, 1, "Snake Game");

    // Highlight the selected game
    switch (selector) 
			{
        case MEMORY_GAME:
            GLCD_SetBackColor(Red);
            GLCD_SetTextColor(White);
            GLCD_DisplayString(4, 2, 1, "Memory Game");
            GLCD_SetBackColor(Black);
            GLCD_SetTextColor(Blue);
            GLCD_DisplayString(5, 2, 1, "Snake Game");
            break;
        case SNAKE_GAME:
            GLCD_DisplayString(4, 2, 1, "Memory Game");
            GLCD_SetBackColor(Red);
            GLCD_SetTextColor(White);
            GLCD_DisplayString(5, 2, 1, "Snake Game");
            GLCD_SetBackColor(Black);
            GLCD_SetTextColor(Blue);
            break;
		}
}

// Execute the selected game in Game Centre
void executeGameCentreTask(int selector) 
{
    GLCD_Clear(White); // Clear screen for task execution
    switch (selector) 
		{
        case MEMORY_GAME:
            game_on(); // Start memory game
            break;
        case SNAKE_GAME:
            snakegame(); // Start snake game
            break;
        default:
            break;
    }
    resetMainMenu(); // Return to main menu after task
}
