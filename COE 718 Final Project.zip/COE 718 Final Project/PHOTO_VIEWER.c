
// LPC17xx definitions         
#include <LPC17xx.H> 
#include "PHOTO_VIEWER.h"
#include "GLCD.h"
#include "LED.h"
#include "KBD.h"
#include "blue eyes.c"
#include "re.c"
#include "potofgreed.c"

extern unsigned char be[];
extern unsigned char re[];
extern unsigned char DarkMagician[];
int counterr;

// Main Function
void display_image(int which)		
{
	int delay = 0;
	if (which==0)
	{
		GLCD_Clear(Black);
		GLCD_Bitmap(80,60,110,160,(unsigned char *)GIMP_BLUEEYES_pixel_data);
	}
	else if (which==1)
	{
		GLCD_Clear(Black);
		GLCD_Bitmap(80,60,111,160,(unsigned char *)GIMP_RE_pixel_data);
	}
	else if (which==2)
	{
		GLCD_Clear(Black);
		GLCD_Bitmap(80,60,109,160,(unsigned char *)GIMP_POTOFGREED_pixel_data);
	}
}

// Photo Viewer
void photo_viewer (int mode)
{	
	int zoom=0;
	int pic     =  0, DELAY = 0;	
	int timer   =  0;
	unsigned char *picture_ptr =0;
	int joystick_prev = get_button();
	int joystick_val = get_button();
	counterr=0;
	display_image(pic);
	while (timer <1)		
	{	
		joystick_val = get_button();	
		if (joystick_val != joystick_prev)	
			{
				if (joystick_val == KBD_RIGHT)
					{
							pic = pic+1; 
							pic = pic%3;	
						  display_image(pic);	
							zoom = 0;
					}
				else if (joystick_val ==KBD_LEFT)
					{
						pic = pic-1;
						if (pic < 0)
								pic = 2;			
						display_image(pic);	
						zoom = 0;
					}
				else if (joystick_val ==KBD_SELECT)
				{
					timer ++;
				}
			  joystick_prev = joystick_val;
				counterr =0;
		}
		if (counterr >= 50)	
		{
			pic = pic+1; 
			pic = pic%3;	
			display_image(pic);
			counterr =0;
			zoom = 0;
			
		}	
	}
	timer = 0;	
	GLCD_Clear(White);
	GLCD_DisplayString (0, 0, 1, "COE 718 Project Demo");
	GLCD_DisplayString (1, 6, 1, "MAIN MENU");
}





